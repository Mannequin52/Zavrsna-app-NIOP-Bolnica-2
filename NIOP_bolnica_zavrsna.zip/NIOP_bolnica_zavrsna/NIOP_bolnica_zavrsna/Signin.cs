﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows.Forms;


namespace NIOP_bolnica_zavrsna
{
    public partial class Signin : Form
    {
        public Signin()
        {
            InitializeComponent();
        }

        List<Osoba> osobe = new List<Osoba>();

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Osoba osoba = new Osoba(textImeD.Text, textPrezD.Text, textOib.Text, textDatRodD.Text, textEmailD.Text, textLozD.Text, textLozDProv.Text);

                textImeD.Clear();
                textPrezD.Clear();
                textOib.Clear();
                textDatRodD.Clear();
                textEmailD.Clear();
                textLozD.Clear();
                textLozDProv.Clear();


                osobe.Add(osoba);

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    using (var writer = new StreamWriter(saveFileDialog.FileName))
                    using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                    {
                        csv.WriteRecords(osobe);
                    }
                }

            }
            catch (Exception greska)
            {
                MessageBox.Show(greska.Message, "Pogresan unos",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}

