﻿using System.Runtime.Remoting.Messaging;
using System.Windows.Forms;

namespace NIOP_bolnica_zavrsna
{
    internal class Osoba
    {
        string ime, prezime, oib, datRod, email, lozinka, lozinka2;
        private string text1;
        private string text2;
        private TextBox textOib;
        private TextBox textDatRodD;
        private TextBox textEmailD;
        private TextBox textLozD;

        public Osoba(string text1, string text2, TextBox textOib, TextBox textDatRodD, TextBox textEmailD, TextBox textLozD)
        {
            this.text1 = text1;
            this.text2 = text2;
            this.textOib = textOib;
            this.textDatRodD = textDatRodD;
            this.textEmailD = textEmailD;
            this.textLozD = textLozD;
        }

        public Osoba(string ime, string prezime, string oib, string datRod, string email, string lozinka, string lozinka2)
        {
            this.Ime = ime;
            this.Prezime = prezime;
            this.Oib = oib;
            this.DatRod = datRod;
            this.Email = email;
            this.Lozinka = lozinka;
            this.Lozinka2 = lozinka2;
        }
        #region get/set
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string Oib { get => oib; set => oib = value; }
        public string DatRod { get => datRod; set => datRod = value; }
        public string Email { get => email; set => email = value; }
        public string Lozinka { get => lozinka; set => lozinka = value; }
        public string Lozinka2 { get => lozinka2; set => lozinka2 = value; }
        #endregion
    }
}