﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NIOP_bolnica_zavrsna
{
    internal class Pacijent
    {
        string ime, prezime, adresa, godiste, oib, boluje;
            char spol;

        public Pacijent(string ime, string prezime, string adresa, string godiste, string oib, string boluje, char spol)
        {
            this.Ime = ime;
            this.Prezime = prezime;
            this.Adresa = adresa;
            this.Godiste = godiste;
            this.Oib = oib;
            this.Boluje = boluje;
            this.Spol = spol;
        }

        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string Adresa { get => adresa; set => adresa = value; }
        public string Godiste { get => godiste; set => godiste = value; }
        public string Oib { get => oib; set => oib = value; }
        public string Boluje { get => boluje; set => boluje = value; }
        public char Spol { get => spol; set => spol = value; }

        public override string ToString()
        {
            string ispis = (this.ime + "\t\t" + this.prezime + "\t\t" + this.spol + "\t\t" + this.boluje + "\t\t" + this.oib + "\t\t" + this.godiste + "\t\t" + this.adresa);
            return base.ToString();
        }
    }


}
