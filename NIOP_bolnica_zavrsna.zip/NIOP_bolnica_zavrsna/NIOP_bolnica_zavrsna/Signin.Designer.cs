﻿namespace NIOP_bolnica_zavrsna
{
    partial class Signin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textImeD = new System.Windows.Forms.TextBox();
            this.textPrezD = new System.Windows.Forms.TextBox();
            this.textDatRodD = new System.Windows.Forms.TextBox();
            this.textEmailD = new System.Windows.Forms.TextBox();
            this.textOib = new System.Windows.Forms.TextBox();
            this.textLozD = new System.Windows.Forms.TextBox();
            this.textLozDProv = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label1.Location = new System.Drawing.Point(49, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label2.Location = new System.Drawing.Point(48, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prezime:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label3.Location = new System.Drawing.Point(280, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(195, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Datum rođenja: (DD/MM/YYYY)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label4.Location = new System.Drawing.Point(184, 267);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "E-mail:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label5.Location = new System.Drawing.Point(280, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "OIB:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label6.Location = new System.Drawing.Point(194, 310);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Lozinka:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label7.Location = new System.Drawing.Point(193, 378);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Lozinka (opet):";
            // 
            // textImeD
            // 
            this.textImeD.Location = new System.Drawing.Point(52, 96);
            this.textImeD.Name = "textImeD";
            this.textImeD.Size = new System.Drawing.Size(180, 20);
            this.textImeD.TabIndex = 7;
            // 
            // textPrezD
            // 
            this.textPrezD.Location = new System.Drawing.Point(51, 159);
            this.textPrezD.Name = "textPrezD";
            this.textPrezD.Size = new System.Drawing.Size(180, 20);
            this.textPrezD.TabIndex = 8;
            // 
            // textDatRodD
            // 
            this.textDatRodD.Location = new System.Drawing.Point(283, 159);
            this.textDatRodD.Name = "textDatRodD";
            this.textDatRodD.Size = new System.Drawing.Size(180, 20);
            this.textDatRodD.TabIndex = 9;
            // 
            // textEmailD
            // 
            this.textEmailD.Location = new System.Drawing.Point(237, 266);
            this.textEmailD.Name = "textEmailD";
            this.textEmailD.Size = new System.Drawing.Size(180, 20);
            this.textEmailD.TabIndex = 10;
            // 
            // textOib
            // 
            this.textOib.Location = new System.Drawing.Point(283, 96);
            this.textOib.Name = "textOib";
            this.textOib.Size = new System.Drawing.Size(180, 20);
            this.textOib.TabIndex = 11;
            // 
            // textLozD
            // 
            this.textLozD.Location = new System.Drawing.Point(196, 329);
            this.textLozD.Name = "textLozD";
            this.textLozD.Size = new System.Drawing.Size(127, 20);
            this.textLozD.TabIndex = 12;
            // 
            // textLozDProv
            // 
            this.textLozDProv.Location = new System.Drawing.Point(197, 397);
            this.textLozDProv.Name = "textLozDProv";
            this.textLozDProv.Size = new System.Drawing.Size(127, 20);
            this.textLozDProv.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.button1.Location = new System.Drawing.Point(213, 482);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 40);
            this.button1.TabIndex = 14;
            this.button1.Text = "Uredu";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.button2.Location = new System.Drawing.Point(28, 482);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 40);
            this.button2.TabIndex = 15;
            this.button2.Text = "Odustani";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(181, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(157, 31);
            this.label8.TabIndex = 16;
            this.label8.Text = "Registracija";
            // 
            // Signin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 556);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textLozDProv);
            this.Controls.Add(this.textLozD);
            this.Controls.Add(this.textOib);
            this.Controls.Add(this.textEmailD);
            this.Controls.Add(this.textDatRodD);
            this.Controls.Add(this.textPrezD);
            this.Controls.Add(this.textImeD);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Signin";
            this.Text = "Registracija";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textImeD;
        private System.Windows.Forms.TextBox textPrezD;
        private System.Windows.Forms.TextBox textDatRodD;
        private System.Windows.Forms.TextBox textEmailD;
        private System.Windows.Forms.TextBox textOib;
        private System.Windows.Forms.TextBox textLozD;
        private System.Windows.Forms.TextBox textLozDProv;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label8;
    }
}